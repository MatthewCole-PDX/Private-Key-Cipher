Matthew Cole - macole@pdx.edu

Description:
The following program is an asymmetric public key cipher, that converts a plaintext file called 'ptext.txt' into a ciphertext file called 'ctext.txt' using a public key and then decrypts using a private key. After the first keys are created, they will be stored in 'pubkey.txt' and 'privkey.txt', respectively.

Instructions:
To build the program, use the makefile and type 'make' into the command line from inside the program directory. Once compiled, run 'main' by typing './main'. If you wish to delete you compilation type 'make clean'. You must input text from a '.txt' file called 'ptext.txt'. Note: the character limit is set to 5000. If you would like to read a larger file you must change this bufferSize in asymmetric.cpp:

Files Included:
1. 'main.cpp' - the program engine, which calls all public functions.
2. 'asymmetric.cpp' - the source file, containing all public and private function implementations.
2. 'asymmetric.h' - the header file, containing the class declaration 'asymmetric' and all of it's public and private functions and variables.
4. 'ptext.txt' - a sample input text file.
5. 'Makefile' - file needed to compile program using the Make function, otherwise you may compile using the method of your choice, but ensure to use c++11.
